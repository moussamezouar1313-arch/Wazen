import '../models/models.dart';

/// نتيجة حساب Safe-to-Spend مع كل العناصر التي أدخلت في الحساب،
/// حتى تستطيع الواجهة تفسير الرقم للمستخدم إن احتاج ذلك.
class SafeToSpendResult {
  final double totalBalance; // إجمالي كل الحسابات
  final double personalBalance; // بدون حسابات "نشاط" في وضع العامل الحر
  final double reserved; // محجوز للالتزامات + الأهداف + الاحتياط
  final int daysUntilNextPayday;
  final double safeToSpendPerDay;

  SafeToSpendResult({
    required this.totalBalance,
    required this.personalBalance,
    required this.reserved,
    required this.daysUntilNextPayday,
    required this.safeToSpendPerDay,
  });
}

class FinancialEngine {
  /// تاريخ موعد الدخل القادم بناءً على يوم الراتب المحدد في الملف الشخصي.
  static DateTime nextPayday(UserProfile profile, DateTime now) {
    final day = profile.paydayDayOfMonth.clamp(1, 28);
    var candidate = DateTime(now.year, now.month, day);
    if (!candidate.isAfter(now)) {
      candidate = DateTime(now.year, now.month + 1, day);
    }
    return candidate;
  }

  /// مجموع الالتزامات المستحقة قبل موعد الراتب القادم.
  static double obligationsDueBefore(
      List<ObligationModel> obligations, DateTime deadline) {
    return obligations
        .where((o) => !o.dueDate.isAfter(deadline))
        .fold(0.0, (sum, o) => sum + o.amount);
  }

  /// مساهمة شهرية تقريبية مطلوبة لكل هدف (تُستخدم كمبلغ محجوز).
  static double monthlyGoalReserve(List<GoalModel> goals, DateTime now) {
    double sum = 0;
    for (final g in goals) {
      if (g.targetDate == null) continue;
      final remaining = g.targetAmount - g.currentAmount;
      if (remaining <= 0) continue;
      final monthsLeft = _monthsBetween(now, g.targetDate!).clamp(1, 999);
      sum += remaining / monthsLeft;
    }
    return sum;
  }

  static int _monthsBetween(DateTime a, DateTime b) {
    return (b.year - a.year) * 12 + (b.month - a.month);
  }

  /// الحساب المركزي: Safe-to-Spend.
  /// personalOnly: في وضع العامل الحر، نستثني حسابات النشاط من "المتاح للسحب الشخصي".
  static SafeToSpendResult compute({
    required UserProfile profile,
    required List<AccountModel> accounts,
    required List<ObligationModel> obligations,
    required List<GoalModel> goals,
    required DateTime now,
  }) {
    final totalBalance =
        accounts.fold(0.0, (sum, a) => sum + a.balance);
    final personalBalance = profile.mode == UserMode.freelance
        ? accounts
            .where((a) => a.type != AccountType.business)
            .fold(0.0, (sum, a) => sum + a.balance)
        : totalBalance;

    final payday = nextPayday(profile, now);
    final daysLeft = payday.difference(now).inDays.clamp(1, 60);

    final reservedObligations = obligationsDueBefore(obligations, payday);
    final reservedGoals = monthlyGoalReserve(goals, now);
    final reserved = reservedObligations + reservedGoals + profile.reserveTarget;

    final available = (personalBalance - reserved).clamp(0, double.infinity);
    final perDay = available / daysLeft;

    return SafeToSpendResult(
      totalBalance: totalBalance,
      personalBalance: personalBalance,
      reserved: reserved,
      daysUntilNextPayday: daysLeft,
      safeToSpendPerDay: perDay,
    );
  }

  /// تطبيق معاملة على قائمة الحسابات وإرجاع نسخة محدّثة (بدون كتابة مباشرة).
  static List<AccountModel> applyTransaction(
      List<AccountModel> accounts, TransactionModel tx) {
    return accounts.map((a) {
      if (tx.type == TxType.income && a.id == tx.accountId) {
        return a.copyWith(balance: a.balance + tx.amount);
      }
      if (tx.type == TxType.expense && a.id == tx.accountId) {
        return a.copyWith(balance: a.balance - tx.amount);
      }
      if (tx.type == TxType.transfer) {
        // التحويل الداخلي لا يُحتسب كدخل أو مصروف على مستوى المحرك،
        // فقط تحرك الأرصدة بين حسابين.
        if (a.id == tx.accountId) {
          return a.copyWith(balance: a.balance - tx.amount);
        }
        if (a.id == tx.toAccountId) {
          return a.copyWith(balance: a.balance + tx.amount);
        }
      }
      return a;
    }).toList();
  }
}
