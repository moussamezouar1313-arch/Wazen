import 'package:hive_flutter/hive_flutter.dart';
import '../models/models.dart';

/// طبقة تخزين محلي واحدة (Offline-first) فوق Hive.
/// كل الشاشات تمر من هنا — لا وصول مباشر لقواعد البيانات من الواجهات.
class Repository {
  static const _settingsBox = 'settings';
  static const _profileBox = 'profile';
  static const _accountsBox = 'accounts';
  static const _transactionsBox = 'transactions';
  static const _obligationsBox = 'obligations';
  static const _goalsBox = 'goals';

  static Future<void> init() async {
    await Hive.initFlutter();
    await Hive.openBox(_settingsBox);
    await Hive.openBox(_profileBox);
    await Hive.openBox(_accountsBox);
    await Hive.openBox(_transactionsBox);
    await Hive.openBox(_obligationsBox);
    await Hive.openBox(_goalsBox);
  }

  // ---------- Onboarding lock ----------
  static bool get onboardingComplete =>
      Hive.box(_settingsBox).get('onboardingComplete', defaultValue: false);

  static Future<void> completeOnboarding() =>
      Hive.box(_settingsBox).put('onboardingComplete', true);

  /// إعادة التهيئة الكاملة: يمسح كل شيء ويعيد المستخدم لشاشة الاختيار الأولى.
  /// هذا هو البديل الآمن الوحيد لتغيير موظف/عامل حر بعد القفل النهائي.
  static Future<void> resetApp() async {
    await Hive.box(_settingsBox).clear();
    await Hive.box(_profileBox).clear();
    await Hive.box(_accountsBox).clear();
    await Hive.box(_transactionsBox).clear();
    await Hive.box(_obligationsBox).clear();
    await Hive.box(_goalsBox).clear();
  }

  // ---------- Profile ----------
  static UserProfile? getProfile() {
    final map = Hive.box(_profileBox).get('profile');
    if (map == null) return null;
    return UserProfile.fromMap(Map<String, dynamic>.from(map));
  }

  static Future<void> saveProfile(UserProfile p) =>
      Hive.box(_profileBox).put('profile', p.toMap());

  // ---------- Accounts ----------
  static List<AccountModel> getAccounts() => Hive.box(_accountsBox)
      .values
      .map((m) => AccountModel.fromMap(Map<String, dynamic>.from(m)))
      .toList();

  static Future<void> saveAccount(AccountModel a) =>
      Hive.box(_accountsBox).put(a.id, a.toMap());

  // ---------- Transactions ----------
  static List<TransactionModel> getTransactions() {
    final list = Hive.box(_transactionsBox)
        .values
        .map((m) => TransactionModel.fromMap(Map<String, dynamic>.from(m)))
        .toList();
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  static Future<void> saveTransaction(TransactionModel t) =>
      Hive.box(_transactionsBox).put(t.id, t.toMap());

  static Future<void> deleteTransaction(String id) =>
      Hive.box(_transactionsBox).delete(id);

  // ---------- Obligations ----------
  static List<ObligationModel> getObligations() => Hive.box(_obligationsBox)
      .values
      .map((m) => ObligationModel.fromMap(Map<String, dynamic>.from(m)))
      .toList();

  static Future<void> saveObligation(ObligationModel o) =>
      Hive.box(_obligationsBox).put(o.id, o.toMap());

  static Future<void> deleteObligation(String id) =>
      Hive.box(_obligationsBox).delete(id);

  // ---------- Goals ----------
  static List<GoalModel> getGoals() => Hive.box(_goalsBox)
      .values
      .map((m) => GoalModel.fromMap(Map<String, dynamic>.from(m)))
      .toList();

  static Future<void> saveGoal(GoalModel g) =>
      Hive.box(_goalsBox).put(g.id, g.toMap());

  static Future<void> deleteGoal(String id) =>
      Hive.box(_goalsBox).delete(id);
}
