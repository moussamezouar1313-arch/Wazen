import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../services/repository.dart';
import '../services/financial_engine.dart';

final onboardingCompleteProvider = StateProvider<bool>(
  (ref) => Repository.onboardingComplete,
);

final profileProvider = StateNotifierProvider<ProfileNotifier, UserProfile?>(
  (ref) => ProfileNotifier(),
);

class ProfileNotifier extends StateNotifier<UserProfile?> {
  ProfileNotifier() : super(Repository.getProfile());

  Future<void> save(UserProfile p) async {
    await Repository.saveProfile(p);
    state = p;
  }
}

final accountsProvider =
    StateNotifierProvider<AccountsNotifier, List<AccountModel>>(
  (ref) => AccountsNotifier(),
);

class AccountsNotifier extends StateNotifier<List<AccountModel>> {
  AccountsNotifier() : super(Repository.getAccounts());

  Future<void> add(AccountModel a) async {
    await Repository.saveAccount(a);
    state = Repository.getAccounts();
  }

  Future<void> applyTransaction(TransactionModel tx) async {
    final updated = FinancialEngine.applyTransaction(state, tx);
    for (final a in updated) {
      await Repository.saveAccount(a);
    }
    state = updated;
  }
}

final transactionsProvider =
    StateNotifierProvider<TransactionsNotifier, List<TransactionModel>>(
  (ref) => TransactionsNotifier(ref),
);

class TransactionsNotifier extends StateNotifier<List<TransactionModel>> {
  final Ref ref;
  TransactionsNotifier(this.ref) : super(Repository.getTransactions());

  Future<void> add(TransactionModel tx) async {
    await Repository.saveTransaction(tx);
    await ref.read(accountsProvider.notifier).applyTransaction(tx);
    state = Repository.getTransactions();
  }

  Future<void> remove(String id) async {
    await Repository.deleteTransaction(id);
    state = Repository.getTransactions();
  }
}

final obligationsProvider =
    StateNotifierProvider<ObligationsNotifier, List<ObligationModel>>(
  (ref) => ObligationsNotifier(),
);

class ObligationsNotifier extends StateNotifier<List<ObligationModel>> {
  ObligationsNotifier() : super(Repository.getObligations());

  Future<void> add(ObligationModel o) async {
    await Repository.saveObligation(o);
    state = Repository.getObligations();
  }

  Future<void> remove(String id) async {
    await Repository.deleteObligation(id);
    state = Repository.getObligations();
  }
}

final goalsProvider = StateNotifierProvider<GoalsNotifier, List<GoalModel>>(
  (ref) => GoalsNotifier(),
);

class GoalsNotifier extends StateNotifier<List<GoalModel>> {
  GoalsNotifier() : super(Repository.getGoals());

  Future<void> add(GoalModel g) async {
    await Repository.saveGoal(g);
    state = Repository.getGoals();
  }

  Future<void> contribute(String id, double amount) async {
    final goal = state.firstWhere((g) => g.id == id);
    final updated = goal.copyWith(currentAmount: goal.currentAmount + amount);
    await Repository.saveGoal(updated);
    state = Repository.getGoals();
  }

  Future<void> remove(String id) async {
    await Repository.deleteGoal(id);
    state = Repository.getGoals();
  }
}

/// النتيجة المركزية: Safe-to-Spend، تُعاد حسابها تلقائياً كل مرة تتغيّر
/// فيها الحسابات أو الالتزامات أو الأهداف (بفضل ref.watch).
final safeToSpendProvider = Provider<SafeToSpendResult?>((ref) {
  final profile = ref.watch(profileProvider);
  if (profile == null) return null;
  final accounts = ref.watch(accountsProvider);
  final obligations = ref.watch(obligationsProvider);
  final goals = ref.watch(goalsProvider);
  return FinancialEngine.compute(
    profile: profile,
    accounts: accounts,
    obligations: obligations,
    goals: goals,
    now: DateTime.now(),
  );
});
