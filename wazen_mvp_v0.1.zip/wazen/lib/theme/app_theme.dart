import 'package:flutter/material.dart';

/// ألوان أساسية للمشروع كله — مرجع واحد بدل تكرار الأكواد اللونية.
class WazenColors {
  static const income = Color(0xFF2ECC71); // أخضر
  static const expense = Color(0xFFE74C3C); // أحمر
  static const warning = Color(0xFFF1C40F);
  static const bgDark = Color(0xFF0E1116);
  static const bgLight = Color(0xFFF4F6F8);
  static const glassDark = Color(0x33FFFFFF);
  static const glassLight = Color(0x66FFFFFF);
}

class AppTheme {
  static ThemeData dark() {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: WazenColors.bgDark,
      colorScheme: const ColorScheme.dark(
        primary: WazenColors.income,
        secondary: WazenColors.expense,
      ),
      useMaterial3: true,
      fontFamily: 'Roboto',
    );
  }

  static ThemeData light() {
    return ThemeData(
      brightness: Brightness.light,
      scaffoldBackgroundColor: WazenColors.bgLight,
      colorScheme: const ColorScheme.light(
        primary: WazenColors.income,
        secondary: WazenColors.expense,
      ),
      useMaterial3: true,
      fontFamily: 'Roboto',
    );
  }
}
