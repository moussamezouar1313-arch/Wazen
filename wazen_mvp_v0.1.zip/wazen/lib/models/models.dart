// نماذج البيانات الأساسية لتطبيق وازن.
// نستخدم Map<String,dynamic> مع Hive مباشرة (بدون build_runner) حتى يبقى
// المشروع قابلاً للبناء فوراً بدون خطوة توليد كود إضافية.

enum UserMode { employee, freelance }

extension UserModeX on UserMode {
  String get key => this == UserMode.employee ? 'employee' : 'freelance';
  static UserMode fromKey(String k) =>
      k == 'freelance' ? UserMode.freelance : UserMode.employee;
}

class UserProfile {
  final String name;
  final UserMode mode;
  final double monthlyIncome; // للموظف: الراتب الصافي
  final int paydayDayOfMonth; // يوم استلام الراتب (1-28)
  final double fixedExpenses; // مجموع المصاريف الثابتة الشهرية
  final double reserveTarget; // احتياط يُحمى دائماً
  final double personalMonthlyTarget; // للعامل الحر: الراتب الذاتي المستهدف

  UserProfile({
    required this.name,
    required this.mode,
    this.monthlyIncome = 0,
    this.paydayDayOfMonth = 1,
    this.fixedExpenses = 0,
    this.reserveTarget = 0,
    this.personalMonthlyTarget = 0,
  });

  Map<String, dynamic> toMap() => {
        'name': name,
        'mode': mode.key,
        'monthlyIncome': monthlyIncome,
        'paydayDayOfMonth': paydayDayOfMonth,
        'fixedExpenses': fixedExpenses,
        'reserveTarget': reserveTarget,
        'personalMonthlyTarget': personalMonthlyTarget,
      };

  factory UserProfile.fromMap(Map map) => UserProfile(
        name: map['name'] ?? '',
        mode: UserModeX.fromKey(map['mode'] ?? 'employee'),
        monthlyIncome: (map['monthlyIncome'] ?? 0).toDouble(),
        paydayDayOfMonth: map['paydayDayOfMonth'] ?? 1,
        fixedExpenses: (map['fixedExpenses'] ?? 0).toDouble(),
        reserveTarget: (map['reserveTarget'] ?? 0).toDouble(),
        personalMonthlyTarget: (map['personalMonthlyTarget'] ?? 0).toDouble(),
      );
}

enum AccountType { cash, bank, card, business }

class AccountModel {
  final String id;
  final String name;
  final AccountType type;
  final double balance;

  AccountModel({
    required this.id,
    required this.name,
    required this.type,
    required this.balance,
  });

  AccountModel copyWith({double? balance, String? name}) => AccountModel(
        id: id,
        name: name ?? this.name,
        type: type,
        balance: balance ?? this.balance,
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'type': type.name,
        'balance': balance,
      };

  factory AccountModel.fromMap(Map map) => AccountModel(
        id: map['id'],
        name: map['name'],
        type: AccountType.values.firstWhere((t) => t.name == map['type'],
            orElse: () => AccountType.cash),
        balance: (map['balance'] ?? 0).toDouble(),
      );
}

enum TxType { income, expense, transfer }

class TransactionModel {
  final String id;
  final TxType type;
  final double amount;
  final String category;
  final String accountId;
  final String? toAccountId; // للتحويلات فقط
  final DateTime date;
  final String note;
  final bool isBusiness; // فقط تُستخدم في وضع العامل الحر

  TransactionModel({
    required this.id,
    required this.type,
    required this.amount,
    required this.category,
    required this.accountId,
    this.toAccountId,
    required this.date,
    this.note = '',
    this.isBusiness = false,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'type': type.name,
        'amount': amount,
        'category': category,
        'accountId': accountId,
        'toAccountId': toAccountId,
        'date': date.toIso8601String(),
        'note': note,
        'isBusiness': isBusiness,
      };

  factory TransactionModel.fromMap(Map map) => TransactionModel(
        id: map['id'],
        type: TxType.values.firstWhere((t) => t.name == map['type'],
            orElse: () => TxType.expense),
        amount: (map['amount'] ?? 0).toDouble(),
        category: map['category'] ?? 'أخرى',
        accountId: map['accountId'],
        toAccountId: map['toAccountId'],
        date: DateTime.parse(map['date']),
        note: map['note'] ?? '',
        isBusiness: map['isBusiness'] ?? false,
      );
}

class ObligationModel {
  final String id;
  final String name;
  final double amount;
  final DateTime dueDate;
  final bool recurringMonthly;

  ObligationModel({
    required this.id,
    required this.name,
    required this.amount,
    required this.dueDate,
    this.recurringMonthly = true,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'amount': amount,
        'dueDate': dueDate.toIso8601String(),
        'recurringMonthly': recurringMonthly,
      };

  factory ObligationModel.fromMap(Map map) => ObligationModel(
        id: map['id'],
        name: map['name'],
        amount: (map['amount'] ?? 0).toDouble(),
        dueDate: DateTime.parse(map['dueDate']),
        recurringMonthly: map['recurringMonthly'] ?? true,
      );
}

class GoalModel {
  final String id;
  final String name;
  final String icon; // إيموجي بسيط بدل صور خارجية
  final double targetAmount;
  final double currentAmount;
  final DateTime? targetDate;

  GoalModel({
    required this.id,
    required this.name,
    required this.icon,
    required this.targetAmount,
    required this.currentAmount,
    this.targetDate,
  });

  double get progress =>
      targetAmount <= 0 ? 0 : (currentAmount / targetAmount).clamp(0, 1);

  GoalModel copyWith({double? currentAmount}) => GoalModel(
        id: id,
        name: name,
        icon: icon,
        targetAmount: targetAmount,
        currentAmount: currentAmount ?? this.currentAmount,
        targetDate: targetDate,
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'icon': icon,
        'targetAmount': targetAmount,
        'currentAmount': currentAmount,
        'targetDate': targetDate?.toIso8601String(),
      };

  factory GoalModel.fromMap(Map map) => GoalModel(
        id: map['id'],
        name: map['name'],
        icon: map['icon'] ?? '🎯',
        targetAmount: (map['targetAmount'] ?? 0).toDouble(),
        currentAmount: (map['currentAmount'] ?? 0).toDouble(),
        targetDate: map['targetDate'] != null
            ? DateTime.parse(map['targetDate'])
            : null,
      );
}
