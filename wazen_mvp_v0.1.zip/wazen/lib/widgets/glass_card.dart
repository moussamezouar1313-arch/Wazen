import 'dart:ui';
import 'package:flutter/material.dart';

/// بطاقة زجاجية بسيطة (Glassmorphism) — بدون حزمة خارجية، بلور + شفافية فقط.
class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double borderRadius;

  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(20),
    this.borderRadius = 24,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(borderRadius),
            color: isDark
                ? Colors.white.withOpacity(0.06)
                : Colors.white.withOpacity(0.55),
            border: Border.all(
              color: Colors.white.withOpacity(isDark ? 0.12 : 0.6),
              width: 1,
            ),
          ),
          child: child,
        ),
      ),
    );
  }
}
