import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../providers/providers.dart';
import '../../models/models.dart';
import '../../theme/app_theme.dart';
import '../../widgets/glass_card.dart';

class TransactionsScreen extends ConsumerWidget {
  const TransactionsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final txs = ref.watch(transactionsProvider);
    final fmt = NumberFormat.decimalPattern('ar');

    return Scaffold(
      appBar: AppBar(title: const Text('المعاملات')),
      body: txs.isEmpty
          ? const Center(child: Text('لا توجد معاملات بعد'))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: txs.length,
              itemBuilder: (context, i) {
                final t = txs[i];
                final isIncome = t.type == TxType.income;
                final isTransfer = t.type == TxType.transfer;
                final color = isTransfer
                    ? Colors.blueGrey
                    : (isIncome ? WazenColors.income : WazenColors.expense);
                return Dismissible(
                  key: ValueKey(t.id),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 20),
                    child: const Icon(Icons.delete, color: Colors.red),
                  ),
                  onDismissed: (_) =>
                      ref.read(transactionsProvider.notifier).remove(t.id),
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: GlassCard(
                      padding: const EdgeInsets.all(14),
                      child: Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: color.withOpacity(0.15),
                            child: Icon(
                              isTransfer
                                  ? Icons.swap_horiz
                                  : (isIncome
                                      ? Icons.arrow_downward
                                      : Icons.arrow_upward),
                              color: color,
                              size: 18,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(t.category,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w600)),
                                Text(
                                  DateFormat('d MMM y', 'ar').format(t.date),
                                  style: const TextStyle(
                                      fontSize: 11, color: Colors.grey),
                                ),
                              ],
                            ),
                          ),
                          Text(
                            '${isIncome ? '+' : (isTransfer ? '' : '-')}'
                            '${fmt.format(t.amount.round())} DZD',
                            style: TextStyle(
                                color: color, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
