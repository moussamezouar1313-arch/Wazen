import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../../models/models.dart';
import '../../providers/providers.dart';
import '../../theme/app_theme.dart';

const _defaultCategories = [
  '🍽️ أكل',
  '🚗 نقل',
  '🏠 منزل',
  '💡 فواتير',
  '💊 صحة',
  '👕 ملابس',
  '🎉 ترفيه',
  '🛍️ تسوق',
  '🧰 عمل',
  '📦 أخرى',
];

class AddTransactionScreen extends ConsumerStatefulWidget {
  const AddTransactionScreen({super.key});

  @override
  ConsumerState<AddTransactionScreen> createState() =>
      _AddTransactionScreenState();
}

class _AddTransactionScreenState extends ConsumerState<AddTransactionScreen> {
  TxType _type = TxType.expense;
  final _amount = TextEditingController();
  String _category = _defaultCategories.first;
  String? _accountId;
  String? _toAccountId;
  bool _isBusiness = false;

  @override
  Widget build(BuildContext context) {
    final accounts = ref.watch(accountsProvider);
    final profile = ref.watch(profileProvider);
    _accountId ??= accounts.isNotEmpty ? accounts.first.id : null;

    return Scaffold(
      appBar: AppBar(title: const Text('معاملة جديدة')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            SegmentedButton<TxType>(
              segments: const [
                ButtonSegment(
                    value: TxType.expense,
                    label: Text('مصروف'),
                    icon: Icon(Icons.arrow_upward)),
                ButtonSegment(
                    value: TxType.income,
                    label: Text('دخل'),
                    icon: Icon(Icons.arrow_downward)),
                ButtonSegment(
                    value: TxType.transfer,
                    label: Text('تحويل'),
                    icon: Icon(Icons.swap_horiz)),
              ],
              selected: {_type},
              onSelectionChanged: (s) => setState(() => _type = s.first),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _amount,
              keyboardType: TextInputType.number,
              autofocus: true,
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              decoration: const InputDecoration(
                labelText: 'المبلغ (DZD)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            if (_type != TxType.transfer) ...[
              const Text('الفئة', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _defaultCategories
                    .map((c) => ChoiceChip(
                          label: Text(c),
                          selected: _category == c,
                          onSelected: (_) => setState(() => _category = c),
                        ))
                    .toList(),
              ),
              const SizedBox(height: 20),
            ],
            const Text('من الحساب', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: _accountId,
              items: accounts
                  .map((a) => DropdownMenuItem(value: a.id, child: Text(a.name)))
                  .toList(),
              onChanged: (v) => setState(() => _accountId = v),
              decoration: const InputDecoration(border: OutlineInputBorder()),
            ),
            if (_type == TxType.transfer) ...[
              const SizedBox(height: 16),
              const Text('إلى الحساب', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: _toAccountId,
                items: accounts
                    .where((a) => a.id != _accountId)
                    .map((a) =>
                        DropdownMenuItem(value: a.id, child: Text(a.name)))
                    .toList(),
                onChanged: (v) => setState(() => _toAccountId = v),
                decoration: const InputDecoration(border: OutlineInputBorder()),
              ),
            ],
            if (profile?.mode == UserMode.freelance &&
                _type != TxType.transfer) ...[
              const SizedBox(height: 8),
              SwitchListTile(
                value: _isBusiness,
                onChanged: (v) => setState(() => _isBusiness = v),
                title: const Text('هذه معاملة تخص النشاط/الورشة'),
                contentPadding: EdgeInsets.zero,
              ),
            ],
            const SizedBox(height: 24),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: _type == TxType.income
                    ? WazenColors.income
                    : (_type == TxType.expense ? WazenColors.expense : null),
              ),
              onPressed: _canSave() ? _save : null,
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Text('حفظ'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  bool _canSave() {
    final amount = double.tryParse(_amount.text);
    if (amount == null || amount <= 0) return false;
    if (_accountId == null) return false;
    if (_type == TxType.transfer && _toAccountId == null) return false;
    return true;
  }

  Future<void> _save() async {
    final tx = TransactionModel(
      id: const Uuid().v4(),
      type: _type,
      amount: double.parse(_amount.text),
      category: _type == TxType.transfer ? 'تحويل داخلي' : _category,
      accountId: _accountId!,
      toAccountId: _type == TxType.transfer ? _toAccountId : null,
      date: DateTime.now(),
      isBusiness: _isBusiness,
    );
    await ref.read(transactionsProvider.notifier).add(tx);
    if (mounted) Navigator.of(context).pop();
  }
}
