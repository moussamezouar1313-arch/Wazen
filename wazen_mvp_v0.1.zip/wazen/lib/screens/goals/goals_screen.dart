import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../../providers/providers.dart';
import '../../models/models.dart';
import '../../widgets/glass_card.dart';

class GoalsScreen extends ConsumerWidget {
  const GoalsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final goals = ref.watch(goalsProvider);
    final fmt = NumberFormat.decimalPattern('ar');

    return Scaffold(
      appBar: AppBar(title: const Text('أهدافك المالية')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddGoalSheet(context, ref),
        child: const Icon(Icons.add),
      ),
      body: goals.isEmpty
          ? const Center(child: Text('لا توجد أهداف بعد، أضف واحداً بالزر +'))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: goals.length,
              itemBuilder: (context, i) {
                final g = goals[i];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: GlassCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(g.icon, style: const TextStyle(fontSize: 26)),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(g.name,
                                  style: const TextStyle(
                                      fontSize: 16, fontWeight: FontWeight.bold)),
                            ),
                            Text('${(g.progress * 100).round()}%'),
                          ],
                        ),
                        const SizedBox(height: 10),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: LinearProgressIndicator(
                              value: g.progress.toDouble(), minHeight: 8),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '${fmt.format(g.currentAmount.round())} / '
                          '${fmt.format(g.targetAmount.round())} DZD',
                          style: const TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                        if (g.targetDate != null)
                          Text(
                            'الموعد: ${DateFormat('d MMM y', 'ar').format(g.targetDate!)}',
                            style: const TextStyle(fontSize: 12, color: Colors.grey),
                          ),
                        const SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: TextButton(
                            onPressed: () => _showContributeSheet(context, ref, g),
                            child: const Text('أضف مبلغاً'),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  void _showAddGoalSheet(BuildContext context, WidgetRef ref) {
    final name = TextEditingController();
    final target = TextEditingController();
    final current = TextEditingController(text: '0');
    final icon = TextEditingController(text: '🎯');
    DateTime? date;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 20,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('هدف جديد', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextField(
                controller: icon,
                decoration: const InputDecoration(labelText: 'إيموجي (مثلاً 🚗)')),
            TextField(
                controller: name,
                decoration: const InputDecoration(labelText: 'اسم الهدف')),
            TextField(
                controller: target,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'المبلغ المطلوب')),
            TextField(
                controller: current,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'المبلغ الموجود حالياً')),
            const SizedBox(height: 8),
            FilledButton(
              onPressed: () async {
                final g = GoalModel(
                  id: const Uuid().v4(),
                  name: name.text.trim().isEmpty ? 'هدف' : name.text.trim(),
                  icon: icon.text.trim().isEmpty ? '🎯' : icon.text.trim(),
                  targetAmount: double.tryParse(target.text) ?? 0,
                  currentAmount: double.tryParse(current.text) ?? 0,
                  targetDate: date ?? DateTime.now().add(const Duration(days: 300)),
                );
                await ref.read(goalsProvider.notifier).add(g);
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('إنشاء الهدف'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showContributeSheet(BuildContext context, WidgetRef ref, GoalModel g) {
    final amount = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 20,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('أضف مبلغاً لهدف ${g.name}',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextField(
              controller: amount,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'المبلغ'),
            ),
            const SizedBox(height: 8),
            FilledButton(
              onPressed: () async {
                final v = double.tryParse(amount.text) ?? 0;
                if (v > 0) {
                  await ref.read(goalsProvider.notifier).contribute(g.id, v);
                }
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('تأكيد'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
