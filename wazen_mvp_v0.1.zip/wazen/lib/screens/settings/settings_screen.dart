import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/providers.dart';
import '../../services/repository.dart';
import '../onboarding/onboarding_choice_screen.dart';
import '../../widgets/glass_card.dart';

/// شاشة "المزيد": كل الميزات الثانوية مجمّعة هنا بدل تعقيد الواجهة الرئيسية.
/// كل مجموعة (Section) تحتوي عناصرها الخاصة — يسهل إضافة ميزات لاحقاً
/// (Edge Panel، الصوت، النسخ الاحتياطي...) بدون تغيير بنية الملاحة العامة.
class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(profileProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('المزيد')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _SectionTitle('الحساب'),
          GlassCard(
            child: Column(
              children: [
                _SettingsTile(
                  icon: Icons.person,
                  title: 'وضعك الحالي',
                  trailing: Text(
                    profile?.mode.key == 'freelance' ? 'عامل حر' : 'موظف',
                  ),
                ),
                const Divider(height: 1),
                _SettingsTile(
                  icon: Icons.account_balance_wallet,
                  title: 'الحسابات والمحافظ',
                  onTap: () {},
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _SectionTitle('الإدخال السريع'),
          GlassCard(
            child: Column(
              children: [
                _SettingsTile(
                  icon: Icons.category,
                  title: 'تخصيص الفئات',
                  onTap: () {},
                ),
                const Divider(height: 1),
                _SettingsTile(
                  icon: Icons.gesture,
                  title: 'البار الجانبي (Edge Panel)',
                  trailing: const _ComingSoonChip(),
                ),
                const Divider(height: 1),
                _SettingsTile(
                  icon: Icons.mic,
                  title: 'الإدخال الصوتي',
                  trailing: const _ComingSoonChip(),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _SectionTitle('الأمان والنسخ الاحتياطي'),
          GlassCard(
            child: Column(
              children: [
                _SettingsTile(
                  icon: Icons.lock,
                  title: 'قفل بالبصمة/PIN',
                  trailing: const _ComingSoonChip(),
                ),
                const Divider(height: 1),
                _SettingsTile(
                  icon: Icons.backup,
                  title: 'نسخ احتياطي مشفر',
                  trailing: const _ComingSoonChip(),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _SectionTitle('حول التطبيق'),
          GlassCard(
            child: Column(
              children: [
                _SettingsTile(
                  icon: Icons.info_outline,
                  title: 'وازن — Wazen v0.1 (MVP)',
                ),
                const Divider(height: 1),
                _SettingsTile(
                  icon: Icons.restart_alt,
                  title: 'إعادة التهيئة الكاملة',
                  titleColor: Colors.redAccent,
                  onTap: () => _confirmReset(context, ref),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _confirmReset(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إعادة التهيئة الكاملة'),
        content: const Text(
          'سيُحذف كل شيء نهائياً: حساباتك، معاملاتك، أهدافك، والتزاماتك. '
          'ستعود لشاشة الاختيار الأولى (موظف / عامل حر) من الصفر. '
          'هذا الإجراء لا رجعة فيه، هل أنت متأكد؟',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          TextButton(
            onPressed: () async {
              await Repository.resetApp();
              ref.read(onboardingCompleteProvider.notifier).state = false;
              if (ctx.mounted) {
                Navigator.of(ctx).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const OnboardingChoiceScreen()),
                  (route) => false,
                );
              }
            },
            child: const Text('نعم، احذف كل شيء',
                style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, top: 4),
      child: Text(text,
          style: const TextStyle(fontSize: 13, color: Colors.grey, fontWeight: FontWeight.w600)),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final Color? titleColor;
  final Widget? trailing;
  final VoidCallback? onTap;

  const _SettingsTile({
    required this.icon,
    required this.title,
    this.titleColor,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, size: 20),
      title: Text(title, style: TextStyle(color: titleColor)),
      trailing: trailing ?? (onTap != null ? const Icon(Icons.chevron_left) : null),
      onTap: onTap,
      dense: true,
    );
  }
}

class _ComingSoonChip extends StatelessWidget {
  const _ComingSoonChip();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
      ),
      child: const Text('قريباً', style: TextStyle(fontSize: 10)),
    );
  }
}
