import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../../models/models.dart';
import '../../providers/providers.dart';
import '../../services/repository.dart';
import '../home/home_screen.dart';

class FreelanceOnboardingScreen extends ConsumerStatefulWidget {
  const FreelanceOnboardingScreen({super.key});

  @override
  ConsumerState<FreelanceOnboardingScreen> createState() =>
      _FreelanceOnboardingScreenState();
}

class _FreelanceOnboardingScreenState
    extends ConsumerState<FreelanceOnboardingScreen> {
  final _name = TextEditingController();
  final _personalTarget = TextEditingController(text: '0');
  final _fixed = TextEditingController(text: '0');
  final _reserve = TextEditingController(text: '0');
  final _personalCash = TextEditingController(text: '0');
  final _businessCash = TextEditingController(text: '0');

  Future<void> _finish() async {
    final profile = UserProfile(
      name: _name.text.trim().isEmpty ? 'مستخدم' : _name.text.trim(),
      mode: UserMode.freelance,
      paydayDayOfMonth: 1, // غير مستخدم في هذا الوضع، الاعتماد على السيولة
      fixedExpenses: double.tryParse(_fixed.text) ?? 0,
      reserveTarget: double.tryParse(_reserve.text) ?? 0,
      personalMonthlyTarget: double.tryParse(_personalTarget.text) ?? 0,
    );
    await ref.read(profileProvider.notifier).save(profile);

    final personalStart = double.tryParse(_personalCash.text) ?? 0;
    final businessStart = double.tryParse(_businessCash.text) ?? 0;

    await ref.read(accountsProvider.notifier).add(
          AccountModel(
            id: const Uuid().v4(),
            name: 'شخصي',
            type: AccountType.cash,
            balance: personalStart,
          ),
        );
    await ref.read(accountsProvider.notifier).add(
          AccountModel(
            id: const Uuid().v4(),
            name: 'النشاط / الورشة',
            type: AccountType.business,
            balance: businessStart,
          ),
        );

    await Repository.completeOnboarding();
    ref.read(onboardingCompleteProvider.notifier).state = true;

    if (mounted) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('بيانات العامل الحر')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            _field(_name, 'اسمك', keyboard: TextInputType.text),
            _field(_personalCash, 'رصيدك الشخصي الحالي'),
            _field(_businessCash, 'سيولة النشاط/الورشة الحالية'),
            _field(_fixed, 'مصاريفك الشخصية الثابتة الشهرية'),
            _field(_personalTarget, 'الراتب الذاتي الذي تريده شهرياً'),
            _field(_reserve, 'احتياط تريد حمايته دائماً'),
            const SizedBox(height: 8),
            const Text(
              'ملاحظة: أي مال يدخل لحساب "النشاط" لن يُحسب تلقائياً كمالك '
              'الشخصي — سترى لاحقاً "المتاح للسحب الشخصي" منفصلاً عن رصيد النشاط.',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: _finish,
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Text('ابدأ استخدام وازن'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label,
      {TextInputType keyboard = TextInputType.number}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: TextField(
        controller: c,
        keyboardType: keyboard,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }
}
