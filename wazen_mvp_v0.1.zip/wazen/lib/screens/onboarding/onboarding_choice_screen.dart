import 'package:flutter/material.dart';
import 'employee_onboarding_screen.dart';
import 'freelance_onboarding_screen.dart';
import '../../widgets/glass_card.dart';
import '../../models/models.dart';

class OnboardingChoiceScreen extends StatelessWidget {
  const OnboardingChoiceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 40),
              const Text(
                'وازن',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                'اعرف ما يمكنك إنفاقه، وخطط لما تريد الوصول إليه',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14, color: Colors.grey),
              ),
              const SizedBox(height: 48),
              const Text(
                'من أنت؟',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 4),
              const Text(
                'هذا الاختيار نهائي ويبني عليه التطبيق كل شيء.\n'
                'لا يمكن تغييره لاحقاً إلا بإعادة تهيئة كاملة تمسح كل بياناتك.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: Colors.orangeAccent),
              ),
              const SizedBox(height: 24),
              _ChoiceCard(
                emoji: '💼',
                title: 'موظف',
                subtitle: 'دخل شهري ثابت وموعد راتب معروف',
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) =>
                        const EmployeeOnboardingScreen(mode: UserMode.employee),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              _ChoiceCard(
                emoji: '🛠️',
                title: 'عامل حر / صاحب نشاط',
                subtitle: 'دخل متغيّر، ويفصل مال النشاط عن مالك الشخصي',
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => const FreelanceOnboardingScreen(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ChoiceCard extends StatelessWidget {
  final String emoji;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ChoiceCard({
    required this.emoji,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: GlassCard(
        child: Row(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 36)),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(subtitle,
                      style:
                          const TextStyle(fontSize: 12, color: Colors.grey)),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios, size: 16),
          ],
        ),
      ),
    );
  }
}
