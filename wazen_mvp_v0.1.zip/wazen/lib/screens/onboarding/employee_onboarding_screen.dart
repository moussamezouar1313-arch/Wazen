import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../../models/models.dart';
import '../../providers/providers.dart';
import '../../services/repository.dart';
import '../home/home_screen.dart';

class EmployeeOnboardingScreen extends ConsumerStatefulWidget {
  final UserMode mode;
  const EmployeeOnboardingScreen({super.key, required this.mode});

  @override
  ConsumerState<EmployeeOnboardingScreen> createState() =>
      _EmployeeOnboardingScreenState();
}

class _EmployeeOnboardingScreenState
    extends ConsumerState<EmployeeOnboardingScreen> {
  final _name = TextEditingController();
  final _income = TextEditingController();
  final _payday = TextEditingController(text: '1');
  final _fixed = TextEditingController(text: '0');
  final _reserve = TextEditingController(text: '0');
  final _cash = TextEditingController(text: '0');

  Future<void> _finish() async {
    final profile = UserProfile(
      name: _name.text.trim().isEmpty ? 'مستخدم' : _name.text.trim(),
      mode: UserMode.employee,
      monthlyIncome: double.tryParse(_income.text) ?? 0,
      paydayDayOfMonth: int.tryParse(_payday.text) ?? 1,
      fixedExpenses: double.tryParse(_fixed.text) ?? 0,
      reserveTarget: double.tryParse(_reserve.text) ?? 0,
    );
    await ref.read(profileProvider.notifier).save(profile);

    final startingCash = double.tryParse(_cash.text) ?? 0;
    await ref.read(accountsProvider.notifier).add(
          AccountModel(
            id: const Uuid().v4(),
            name: 'نقد',
            type: AccountType.cash,
            balance: startingCash,
          ),
        );

    await Repository.completeOnboarding();
    ref.read(onboardingCompleteProvider.notifier).state = true;

    if (mounted) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('بيانات الموظف')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            _field(_name, 'اسمك', keyboard: TextInputType.text),
            _field(_income, 'الراتب الشهري الصافي (DZD)'),
            _field(_payday, 'يوم استلام الراتب (1-28)'),
            _field(_fixed, 'مجموع المصاريف الثابتة الشهرية'),
            _field(_reserve, 'مبلغ الاحتياط الذي تريد حمايته دائماً'),
            _field(_cash, 'رصيدك النقدي الحالي'),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: _finish,
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Text('ابدأ استخدام وازن'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label,
      {TextInputType keyboard = TextInputType.number}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: TextField(
        controller: c,
        keyboardType: keyboard,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }
}
