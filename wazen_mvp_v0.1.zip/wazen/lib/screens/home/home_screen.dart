import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../providers/providers.dart';
import '../../theme/app_theme.dart';
import '../../widgets/glass_card.dart';
import '../transactions/transactions_screen.dart';
import '../transactions/add_transaction_screen.dart';
import '../goals/goals_screen.dart';
import '../settings/settings_screen.dart';
import '../../models/models.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const _HomeTab(),
      const TransactionsScreen(),
      const GoalsScreen(),
      const SettingsScreen(),
    ];

    return Scaffold(
      body: pages[_tab],
      floatingActionButton: _tab == 1
          ? FloatingActionButton(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const AddTransactionScreen()),
              ),
              child: const Icon(Icons.add),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'الرئيسية'),
          NavigationDestination(
              icon: Icon(Icons.receipt_long_rounded), label: 'المعاملات'),
          NavigationDestination(icon: Icon(Icons.flag_rounded), label: 'الأهداف'),
          NavigationDestination(icon: Icon(Icons.settings_rounded), label: 'المزيد'),
        ],
      ),
    );
  }
}

class _HomeTab extends ConsumerWidget {
  const _HomeTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(profileProvider);
    final result = ref.watch(safeToSpendProvider);
    final obligations = ref.watch(obligationsProvider)
      ..sort((a, b) => a.dueDate.compareTo(b.dueDate));
    final goals = ref.watch(goalsProvider);
    final fmt = NumberFormat.decimalPattern('ar');

    if (profile == null || result == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final upcoming = obligations.take(3).toList();

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('مرحباً 👋 ${profile.name}',
              style: const TextStyle(fontSize: 18, color: Colors.grey)),
          const SizedBox(height: 16),
          GlassCard(
            child: Column(
              children: [
                const Text('يمكنك إنفاق اليوم',
                    style: TextStyle(fontSize: 14, color: Colors.grey)),
                const SizedBox(height: 8),
                Text(
                  '${fmt.format(result.safeToSpendPerDay.round())} DZD',
                  style: TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.bold,
                    color: result.safeToSpendPerDay > 0
                        ? WazenColors.income
                        : WazenColors.expense,
                  ),
                ),
                const SizedBox(height: 4),
                Text('حتى دخلك القادم: ${result.daysUntilNextPayday} يوماً',
                    style: const TextStyle(fontSize: 12, color: Colors.grey)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _StatCard(
                  label: profile.mode == UserMode.freelance
                      ? 'المتاح شخصياً'
                      : 'الرصيد',
                  value: fmt.format(result.personalBalance.round()),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _StatCard(
                  label: 'محجوز (التزامات/أهداف)',
                  value: fmt.format(result.reserved.round()),
                ),
              ),
            ],
          ),
          if (profile.mode == UserMode.freelance) ...[
            const SizedBox(height: 12),
            _StatCard(
              label: 'إجمالي (شخصي + نشاط)',
              value: fmt.format(result.totalBalance.round()),
            ),
          ],
          if (upcoming.isNotEmpty) ...[
            const SizedBox(height: 20),
            const Text('القادم',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ...upcoming.map((o) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: GlassCard(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      children: [
                        const Icon(Icons.circle,
                            size: 10, color: WazenColors.expense),
                        const SizedBox(width: 10),
                        Expanded(child: Text(o.name)),
                        Text('${fmt.format(o.amount.round())} DZD',
                            style: const TextStyle(fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                )),
          ],
          if (goals.isNotEmpty) ...[
            const SizedBox(height: 20),
            const Text('أهدافك',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ...goals.map((g) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: GlassCard(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(g.icon, style: const TextStyle(fontSize: 20)),
                            const SizedBox(width: 8),
                            Expanded(child: Text(g.name)),
                            Text('${(g.progress * 100).round()}%'),
                          ],
                        ),
                        const SizedBox(height: 8),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: LinearProgressIndicator(
                            value: g.progress.toDouble(),
                            minHeight: 6,
                          ),
                        ),
                      ],
                    ),
                  ),
                )),
          ],
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  const _StatCard({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 11, color: Colors.grey)),
          const SizedBox(height: 4),
          Text('$value DZD',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
